var searchData=
[
  ['fecha',['Fecha',['../classed_1_1Fecha.html#a4200aabbe687e77663fe2013f68742c8',1,'ed::Fecha::Fecha(int dia=1, int mes=1, int agno=1)'],['../classed_1_1Fecha.html#a16ac1c6c216e0ea12b108f98de217c06',1,'ed::Fecha::Fecha(Fecha const &amp;objeto)']]]
];
