var searchData=
[
  ['green',['GREEN',['../macros_8hpp.html#acfbc006ea433ad708fdee3e82996e721',1,'macros.hpp']]]
];
