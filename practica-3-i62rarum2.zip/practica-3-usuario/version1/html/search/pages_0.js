var searchData=
[
  ['implementación_20de_20un_20montículo_20de_20mediciones',['Implementación de un montículo de mediciones',['../index.html',1,'']]]
];
