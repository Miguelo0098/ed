Este comprimido tiene dos versiones:
	- La versión 1 contiene el programa principal otorgado por el profesor para la comprobación de las clases Montículo y Medicion.
	- La versión 2 contiene un programa principal codificado por el alumno.

En cualquiera de los casos, basta con compilarlos con el makefile de la versión correspondiente.
