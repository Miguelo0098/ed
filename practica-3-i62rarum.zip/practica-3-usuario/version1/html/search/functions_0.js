var searchData=
[
  ['borrarmedicionmonticulo',['borrarMedicionMonticulo',['../namespaceed.html#a7f72153dc396c5e7d0546f81d956b65d',1,'ed']]],
  ['borrartodasmediciones',['borrarTodasMediciones',['../namespaceed.html#a9ffa568a8012f457a008c2e3f922ad25',1,'ed']]]
];
